namespace PatientApi.Models;

public class Patient
{
    public Guid Id { get; set; } = Guid.NewGuid();

    public required string FirstName { get; set; }
    public required string LastName { get; set; }

    public DateTime DateOfBirth { get; set; }

    public required string Email { get; set; }

    public Guardian? Guardian { get; set; }
}