namespace PatientApi.Models;

public class Guardian
{
    public required string FirstName { get; set; }
    public required string LastName { get; set; }
}