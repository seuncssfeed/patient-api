using System.Linq;
using Scalar.AspNetCore;
using PatientApi.DTOs;
using PatientApi.Middleware;
using PatientApi.Services;
using PatientApi.Validation;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddOpenApi();
builder.Services.AddSingleton<IPatientService, PatientService>();

var app = builder.Build();

app.UseMiddleware<ExceptionMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference();
}

app.UseHttpsRedirection();

app.MapPost("/patients", (PatientRequest request, IPatientService patientService) =>
{
    var errors = PatientValidation.Validate(request);

    if (errors.Count > 0)
    {
        return Results.ValidationProblem(errors);
    }

    var patient = patientService.CreatePatient(request);

    return Results.Created($"/patients/{patient.Id}", patient);
});

app.MapGet("/patients/{id}", (Guid id, IPatientService patientService) =>
{
    var patient = patientService.GetPatientById(id);

    if (patient is null)
    {
        return Results.NotFound(new
        {
            title = "Patient not found.",
            status = 404,
            detail = $"No patient found with ID {id}."
        });
    }

    return Results.Ok(patient);
});

app.MapGet("/patients", (string? name, DateTime? dateOfBirth, IPatientService patientService) =>
{
    var results = patientService.SearchPatients(name, dateOfBirth);
    return Results.Ok(results);
});

app.MapPut("/patients/{id}", (Guid id, PatientRequest request, IPatientService patientService) =>
{
    var errors = PatientValidation.Validate(request);

    if (errors.Count > 0)
    {
        return Results.ValidationProblem(errors);
    }

    var updatedPatient = patientService.UpdatePatient(id, request);

    if (updatedPatient is null)
    {
        return Results.NotFound(new
        {
            title = "Patient not found.",
            status = 404,
            detail = $"No patient found with ID {id}."
        });
    }

    return Results.Ok(updatedPatient);
});

app.Run();