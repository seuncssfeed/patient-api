namespace PatientApi.DTOs;

public class GuardianRequest
{
    public required string FirstName { get; set; }
    public required string LastName { get; set; }
}