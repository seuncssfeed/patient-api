namespace PatientApi.DTOs;

public class PatientRequest
{
    public required string FirstName { get; set; }
    public required string LastName { get; set; }
    public DateTime DateOfBirth { get; set; }
    public required string Email { get; set; }
    public GuardianRequest? Guardian { get; set; }
}