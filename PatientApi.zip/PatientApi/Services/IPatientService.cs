using PatientApi.DTOs;
using PatientApi.Models;

namespace PatientApi.Services;

public interface IPatientService
{
    Patient CreatePatient(PatientRequest request);
    Patient? GetPatientById(Guid id);
    IEnumerable<Patient> SearchPatients(string? name, DateTime? dateOfBirth);
    Patient? UpdatePatient(Guid id, PatientRequest request);
}