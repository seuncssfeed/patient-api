using PatientApi.DTOs;
using PatientApi.Models;

namespace PatientApi.Services;

public class PatientService : IPatientService
{
    private readonly List<Patient> _patients = new();

    public Patient CreatePatient(PatientRequest request)
    {
        var patient = new Patient
        {
            Id = Guid.NewGuid(),
            FirstName = request.FirstName,
            LastName = request.LastName,
            DateOfBirth = request.DateOfBirth,
            Email = request.Email,
            Guardian = request.Guardian is null
                ? null
                : new Guardian
                {
                    FirstName = request.Guardian.FirstName,
                    LastName = request.Guardian.LastName
                }
        };

        _patients.Add(patient);
        return patient;
    }

    public Patient? GetPatientById(Guid id)
    {
        return _patients.FirstOrDefault(p => p.Id == id);
    }

    public IEnumerable<Patient> SearchPatients(string? name, DateTime? dateOfBirth)
    {
        var query = _patients.AsEnumerable();

        if (!string.IsNullOrWhiteSpace(name))
        {
            query = query.Where(p =>
                p.FirstName.Contains(name, StringComparison.OrdinalIgnoreCase) ||
                p.LastName.Contains(name, StringComparison.OrdinalIgnoreCase));
        }

        if (dateOfBirth.HasValue)
        {
            query = query.Where(p => p.DateOfBirth.Date == dateOfBirth.Value.Date);
        }

        return query;
    }

    public Patient? UpdatePatient(Guid id, PatientRequest request)
    {
        var existingPatient = _patients.FirstOrDefault(p => p.Id == id);

        if (existingPatient is null)
        {
            return null;
        }

        existingPatient.FirstName = request.FirstName;
        existingPatient.LastName = request.LastName;
        existingPatient.DateOfBirth = request.DateOfBirth;
        existingPatient.Email = request.Email;
        existingPatient.Guardian = request.Guardian is null
            ? null
            : new Guardian
            {
                FirstName = request.Guardian.FirstName,
                LastName = request.Guardian.LastName
            };

        return existingPatient;
    }
}