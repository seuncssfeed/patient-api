using PatientApi.DTOs;
using PatientApi.Services;

namespace PatientApi.Tests;

public class PatientServiceTests
{
    [Fact]
    public void CreatePatient_ShouldAddPatientAndReturnIt()
    {
        var service = new PatientService();

        var request = new PatientRequest
        {
            FirstName = "John",
            LastName = "Doe",
            DateOfBirth = new DateTime(2000, 1, 1),
            Email = "john@example.com"
        };

        var result = service.CreatePatient(request);

        Assert.NotNull(result);
        Assert.Equal("John", result.FirstName);
        Assert.Equal("Doe", result.LastName);
        Assert.Equal("john@example.com", result.Email);

        var fetchedPatient = service.GetPatientById(result.Id);
        Assert.NotNull(fetchedPatient);
    }

    [Fact]
    public void GetPatientById_ShouldReturnPatient_WhenPatientExists()
    {
        var service = new PatientService();

        var request = new PatientRequest
        {
            FirstName = "Jane",
            LastName = "Smith",
            DateOfBirth = new DateTime(1995, 5, 15),
            Email = "jane@example.com"
        };

        var createdPatient = service.CreatePatient(request);

        var result = service.GetPatientById(createdPatient.Id);

        Assert.NotNull(result);
        Assert.Equal(createdPatient.Id, result!.Id);
        Assert.Equal("Jane", result.FirstName);
    }

    [Fact]
    public void SearchPatients_ShouldReturnMatchingPatients_ByName()
    {
        var service = new PatientService();

        service.CreatePatient(new PatientRequest
        {
            FirstName = "John",
            LastName = "Doe",
            DateOfBirth = new DateTime(2000, 1, 1),
            Email = "john@example.com"
        });

        service.CreatePatient(new PatientRequest
        {
            FirstName = "Johnny",
            LastName = "Brown",
            DateOfBirth = new DateTime(2001, 1, 1),
            Email = "johnny@example.com"
        });

        var results = service.SearchPatients("John", null).ToList();

        Assert.Equal(2, results.Count);
    }

    [Fact]
    public void UpdatePatient_ShouldModifyExistingPatient()
    {
        var service = new PatientService();

        var createdPatient = service.CreatePatient(new PatientRequest
        {
            FirstName = "John",
            LastName = "Doe",
            DateOfBirth = new DateTime(2000, 1, 1),
            Email = "john@example.com"
        });

        var updateRequest = new PatientRequest
        {
            FirstName = "Johnathan",
            LastName = "Doe",
            DateOfBirth = new DateTime(2000, 1, 1),
            Email = "johnathan@example.com"
        };

        var updatedPatient = service.UpdatePatient(createdPatient.Id, updateRequest);

        Assert.NotNull(updatedPatient);
        Assert.Equal("Johnathan", updatedPatient!.FirstName);
        Assert.Equal("johnathan@example.com", updatedPatient.Email);
    }
}