using PatientApi.DTOs;
using System.Text.RegularExpressions;

namespace PatientApi.Validation;

public static class PatientValidation
{
    public static Dictionary<string, string[]> Validate(PatientRequest request)
    {
        var errors = new Dictionary<string, string[]>();

        if (string.IsNullOrWhiteSpace(request.FirstName))
            errors["firstName"] = new[] { "First name is required." };

        if (string.IsNullOrWhiteSpace(request.LastName))
            errors["lastName"] = new[] { "Last name is required." };

        if (request.DateOfBirth == default)
            errors["dateOfBirth"] = new[] { "Date of birth is required." };

        if (request.DateOfBirth > DateTime.Today)
            errors["dateOfBirth"] = new[] { "Date of birth cannot be in the future." };

        if (string.IsNullOrWhiteSpace(request.Email))
        {
            errors["email"] = new[] { "Email is required." };
        }
        else if (!IsValidEmail(request.Email))
        {
            errors["email"] = new[] { "Email format is invalid." };
        }

        var isUnder18 = request.DateOfBirth > DateTime.Today.AddYears(-18);

        if (isUnder18)
        {
            if (request.Guardian is null)
            {
                errors["guardian"] = new[] { "Guardian is required for patients under 18." };
            }
            else
            {
                var guardianErrors = new List<string>();

                if (string.IsNullOrWhiteSpace(request.Guardian.FirstName))
                    guardianErrors.Add("Guardian first name is required.");

                if (string.IsNullOrWhiteSpace(request.Guardian.LastName))
                    guardianErrors.Add("Guardian last name is required.");

                if (guardianErrors.Count > 0)
                    errors["guardian"] = guardianErrors.ToArray();
            }
        }

        return errors;
    }

    private static bool IsValidEmail(string email)
    {
        return Regex.IsMatch(
            email,
            @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
            RegexOptions.IgnoreCase);
    }
}